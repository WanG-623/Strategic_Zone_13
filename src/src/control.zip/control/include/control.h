#ifndef _CONTROL_H_
#define _CONTROL_H_

#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_ros/point_cloud.h>
#include <pcl_conversions/pcl_conversions.h>
#include <tf/tf.h>
class Point
{
    public:
    double x, y, z;
    Point():x(0.), y(0.), z(0.){
    }

    Point(double x_in, double y_in): x(x_in), y(y_in), z(0.){
    }

    template<typename T>
    Point(T point): x(point.x), y(point.y), z(point.z){
    }

    void setValue(double x, double y){
        this->x = x;
        this->y = y;
        this->z = 0.;
    }

    void setValue(double x, double y, double z){
        this->x = x;
        this->y = y;
        this->z = z;
    }

    bool isOrigin(){
        return this->x == 0 && this->y == 0;
    }

    Point operator+(const Point p){
        Point sum;
        sum.x = x + p.x;
        sum.y = y + p.y;
        sum.z = z + p.z;
        return sum;
    }

    Point operator-(const Point p){
        Point sum;
        sum.x = x - p.x;
        sum.y = y - p.y;
        sum.z = z - p.z;
        return sum;
    }

    Point operator*(const double a){
        Point product;
        product.x = x * a;
        product.y = y * a;
        product.z = z * a;
        return product;
    }

    void operator+= (Point p){
        x += p.x;
        y += p.y;
        z += p.z;
    }

    double distance(Point P){
        return sqrt((x - P.x) * (x - P.x) + (y - P.y) * (y - P.y));
    }

    double polar(Point end){
        return atan2(end.y - y, end.x - x);
    }

    double cross(Point P){
        return x * P.y  - y * P.x;
    }

    double dot(Point P){
        return x * P.x  + y * P.y;
    }

    static Point UnitVec(double yaw){
        Point p;
        p.x = cos(yaw);
        p.y = sin(yaw);
        return p;
    }

    double norm(){
        return sqrt(this->x * this->x + this->y * this->y);
    }

    Point rotate(double yaw){
        Point p;
        p.x = this->x * cos(yaw) - this->y * sin(yaw);
        p.y = this->x * sin(yaw) + this->y * cos(yaw);
        return p;
    }
};

class control  
{
private:
    ros::NodeHandle nx;
    ros::Subscriber subPath;
    ros::Subscriber subOdom;
    ros::Publisher pubTwist;
    std::vector<Point> path;
    pcl::PointCloud<pcl::PointXYZI> pcl_cloud_;
public:
    control(/* args */):nx("~")
{
    subPath=nx.subscribe("/section_map", 1, &control::pathHandler, this);
    subOdom=nx.subscribe("/odom_chassis", 2, &control::twistHandler, this);
    pubTwist = nx.advertise<geometry_msgs::Twist>("/cmd_vel", 1);
};
    ~control()
    {};
public:
double target_speed=0.;
double target_turn=0.;
sensor_msgs::PointCloud2 path_;
nav_msgs::Odometry  twist_; 
void pathHandler(const sensor_msgs::PointCloud2::ConstPtr &msg);
void twistHandler(const nav_msgs::Odometry::ConstPtr &msg);
void loadPath(sensor_msgs::PointCloud2 &cloud);
void loadTwist(nav_msgs::Odometry &twist);
void run();
void curve();
};



#endif