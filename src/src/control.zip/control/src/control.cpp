#include "control.h"

int main(int argc, char **argv)
{
     ros::init(argc, argv, "control");
     control test;
     ros::Rate loop_rate(20);
     while(ros::ok()){
        ros::spinOnce();
        test.run();
        loop_rate.sleep();
    }
}