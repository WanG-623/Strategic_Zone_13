#include "control.h"

void control::loadPath(sensor_msgs::PointCloud2 &cloud)
{
    pcl::fromROSMsg(cloud, pcl_cloud_);
    path.clear();
     for(auto point : pcl_cloud_.points){
        path.push_back(Point(point));
    }
}
void control::loadTwist(nav_msgs::Odometry &   )
{
std::cout<<"***"<<std::endl;
}
  void control::pathHandler(const sensor_msgs::PointCloud2::ConstPtr &msg)
{
    path_=*msg;
    std::cout<<"1"<<std::endl;
}
void control::twistHandler(const nav_msgs::Odometry::ConstPtr &msg)
{
   twist_=*msg;
   std::cout<<"2"<<std::endl;
}
void control::run()
{
    //loadTwist(twist_);
    loadPath(path_);
    curve();
}
void control::curve()
{   std::cout<<"path.size"<<path.size()<<std::endl;
    if(path.size()>31)
    {
        int index=path.size();
        double x_init_pose=path.at(30).x;
        double y_init_pose=path.at(30).y;
        std::cout<<"x de weizhi"<<x_init_pose<<std::endl;
        std::cout<<"y de weizhi"<<y_init_pose<<std::endl;
        Eigen::VectorXd x_1(10), y_1(10);
        Eigen::MatrixXd A(10,4), C, T;
        for(int i=0; i<10; i++){
            x_1(i) = path.at(3*(i+1)).x;
            y_1(i) = path.at(3*(i+1)).y;
        }
	
        
        for(int i=0; i<10; i++){
            for(int j=0; j<4; j++){
                A(i,j) = pow(x_1(i), j);
            }
        }
        C = (A.transpose()*A).inverse();
        T = C*A.transpose()*y_1;
           int idx_=path.size()-1;
           if(idx_>30)
           idx_=30;
          double x_ideal_pose=0.2;
          double y_ideal_pose=T(0,0)+T(1,0)*x_ideal_pose+T(2,0)*x_ideal_pose*x_ideal_pose+T(3,0)*x_ideal_pose*x_ideal_pose*x_ideal_pose;
          std::cout<<T<<std::endl;
          double LatDis_Err=y_ideal_pose;
          double LonDis_Err=x_ideal_pose;
          double Dis_Err=sqrt(LatDis_Err*LatDis_Err+LonDis_Err*LonDis_Err)/5.;
           target_speed=Dis_Err;
           target_turn=LatDis_Err*2.0/(target_speed)/5.;
    }
    std::cout<<"target_speed"<<std::endl;
    std::cout<<target_speed<<std::endl;
    std::cout<<target_turn<<std::endl;
     geometry_msgs::Twist twist;
    twist.angular.z =target_turn;
    twist.linear.x=target_speed;
    twist.linear.z =1; 
   if(1){
        pubTwist.publish(twist);
    }
}  
