/*
  1.将前后100个点放入消息中发布
*/
#include "ros/ros.h"
#include <iostream>
// #include "PlatformMap/GnssImuInfo.h"
// #include "PlatformMap/LocalMapPoint.h"
// #include "PlatformMap/LocalMapLane.h"
#include <visualization_msgs/Marker.h>
#include <geometry_msgs/Point.h>
#include <iostream>
#include <vector>
#include <sstream>
#include <fstream>
#include <string>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/Imu.h>
// #include"chcnav/hcinspvatzcb.h"
#include <GeographicLib/LocalCartesian.hpp>
#include <GeographicLib/Geocentric.hpp>
#include<sensor_msgs/PointCloud2.h>
#include<pcl/point_cloud.h>
#include<pcl_conversions/pcl_conversions.h>
#include "raw_sensor_msgs/ChanavGnss.h"
struct Piont_element
{
    double center_x;
    double center_y;
     double center_z;
    double center_yaw;
    double center_pitch;
    double center_roll;
};
std::string _gps_topic;
std::vector<Piont_element> global_map;
Piont_element  gnssinfo;
std::vector<Piont_element> gnssinfos;

//gps
struct Gnssinfo
{
    double latitude;
    double longitude;
    double altitude;

    double roll;
    double pitch;
    double yaw;
};
static Gnssinfo init_gnssinfo;
std::string _param_path;
std::ifstream read_param;
static GeographicLib::LocalCartesian local_cartesian;

static void load_config_param(const std::string& param_file, Gnssinfo& init_gnssinfo_)
{
    read_param.open(param_file);
    int flag = 0;
    //eof()函数 用于判断是否为空或者到文件结尾
    while(!read_param.eof())
    {
        std::string s;
        std::getline(read_param,s);

        if(!s.empty() && flag == 1)
        {
            std::stringstream ss;
            ss << s;
            ss >> init_gnssinfo_.latitude;
            ss >> init_gnssinfo_.longitude;
            ss >> init_gnssinfo_.altitude; 
        }
        if(!s.empty() && flag == 2)
        {
            std::stringstream ss;
            ss << s;
            ss >> init_gnssinfo_.roll;
            ss >> init_gnssinfo_.pitch;
            ss >> init_gnssinfo_.yaw;
        }
        flag++;
    }
    read_param.close();
}



void chatterCallback(const raw_sensor_msgs::ChanavGnss::ConstPtr& msg)
{
    // std::cout<<"回调函数成功"<<std::endl;
    ROS_INFO("I have received the IMU message!");
    double latitude,longitude,altitude;
    double real_x,real_y,real_z;
    latitude = msg->latitude;
    longitude= msg->longitude;
    altitude = msg->altitude;
 
    local_cartesian.Forward(latitude,longitude,altitude,real_x,real_y,real_z);
    gnssinfo.center_x = real_x;
    gnssinfo.center_y = real_y;
    gnssinfo.center_yaw = msg->yaw;
    gnssinfos.push_back(gnssinfo);
    std::cout<<gnssinfos.size()<<std::endl;
    if(gnssinfos.size()>50){
        gnssinfos.erase(gnssinfos.begin());
    }
    //std::cout << "imuinfos.size: " << std::endl;            
}

void readtxtmap()
{
    Piont_element point_element;
    double element1,element2,element3,element4,element5,element6;

    std::ifstream infile("/home/pm/draw/src/rtk_localization/data/0530.txt");
    if(!infile.is_open())
    {
        std::cout<<"File is not existing!"<<std::endl;
        exit(1);
    }

    for(int i=0;!infile.eof();i++)
    {

        infile>>element1>>element2>>element3>>element4;
        point_element.center_x = element1;
        point_element.center_y = element2;
        point_element.center_z = element3;
        point_element.center_yaw = element4;
        // point_element.center_pitch= element5;
        // point_element.center_roll = element6;
        // std::cout<<"x:"<<  point_element.center_x<<std::endl;
        global_map.push_back(point_element);
    }

    std::cout<<"global_map.size:"<<global_map.size()<<std::endl;
}



int formMapPointsToMarker(const  pcl::PointCloud<pcl::PointXYZ>& lane,visualization_msgs::Marker& line0_strip,  visualization_msgs::Marker& car_body)
{
    geometry_msgs::Point  point_cen,point_carbody;
    std::vector<geometry_msgs::Point> points_cen,points_carbody;
    int idxx = gnssinfos.size() -1;
    int Lens = lane.points.size();
    for(int i = 0; i < Lens; i++)
    { 
        point_cen.z = 0;
        point_cen.x = lane.points[i].x - gnssinfos[idxx].center_x;
        point_cen.y = lane.points[i].y - gnssinfos[idxx].center_y;

        point_carbody.z = 0;
        point_carbody.x = gnssinfos[idxx].center_x;
        point_carbody.y = gnssinfos[idxx].center_y;
        points_cen.push_back(point_cen);
        // points_lef.push_back(point_lef);
        // points_rig.push_back(point_rig);
        points_carbody.push_back(point_carbody);
    }

    line0_strip.header.frame_id = "/vehicle";
    line0_strip.header.stamp = ros::Time(0);
    line0_strip.ns = "tracker_convex";
    line0_strip.id = 10;
    line0_strip.points = points_cen;
    line0_strip.action = visualization_msgs::Marker::ADD;
    line0_strip.pose.orientation.w = 1.0;
    line0_strip.lifetime = ros::Duration(0.1);
    line0_strip.type = visualization_msgs::Marker::LINE_STRIP;
    line0_strip.scale.x = 0.1;
    line0_strip.scale.y = 0.1;
    line0_strip.scale.z = 0.1;
    line0_strip.color.r = 1.0;
    line0_strip.color.g = 1.0;
    line0_strip.color.b = 0.0;
    line0_strip.color.a = 1.0;

    car_body.header.frame_id = "/vehicle";
    car_body.header.stamp = ros::Time(0);
    car_body.ns = "tracker_convex";
    car_body.id = 10;
    car_body.points = points_carbody;
    car_body.action = visualization_msgs::Marker::ADD;
    car_body.pose.orientation.w = 1.0;
    car_body.lifetime = ros::Duration(0.1);
    car_body.type = visualization_msgs::Marker::CUBE;
    car_body.scale.x = 2.0;
    car_body.scale.y = 2.0;
    car_body.scale.z = 2.0;
    car_body.color.r = 1.0f;
    car_body.color.g = 0.0f;
    car_body.color.b = 0.0f;
    car_body.color.a = 1.0;

    return 0;
}

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "line_draw_car_node");
    ros::NodeHandle nh;
    ros::NodeHandle private_nh("~");
    readtxtmap();
  //设置起点
    private_nh.getParam("param_path",_param_path);
    load_config_param(_param_path.c_str(),init_gnssinfo);
    local_cartesian.Reset(init_gnssinfo.latitude, init_gnssinfo.longitude, init_gnssinfo.altitude);
    private_nh.getParam("gps_topic", _gps_topic);
    std::cout << _gps_topic<< std::endl;
    ros::Subscriber gnss_sub = nh.subscribe<raw_sensor_msgs::ChanavGnss>(_gps_topic,1000,chatterCallback);
    ros::Publisher  map_pub = nh.advertise<sensor_msgs::PointCloud2>("/section_map", 1000);
    // ros::Publisher  marker_cen_pub = nh.advertise<visualization_msgs::Marker>("/center_line",100);
    // ros::Publisher  marker_carbody_pub = nh.advertise<visualization_msgs::Marker>("/car_body",100);
 
    // visualization_msgs::Marker  marker_cen;
    // visualization_msgs::Marker  marker_body;
 
    ros::Rate loop_rate(1);

    while(ros::ok())
    {
        std::cout << "gnssinfos: " << gnssinfos.size() << std::endl;
        // pcl::PointCloud<pcl::PointXYZ> cloud;
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_ptr(new pcl::PointCloud<pcl::PointXYZ>);
        cloud_ptr->points.resize(40);
        // cloud.points.resize(200);
        if(gnssinfos.size() > 0)
        
        {
            int idx = gnssinfos.size()-1;
            double realtime_x = gnssinfos[idx].center_x;
            double realtime_y = gnssinfos[idx].center_y;

            int id;
            int mapLens = global_map.size();
            int p_begin,p_end;
            double delta_x,delta_y,delta;
            double near_distance = 10e10;

            for(int i = 0;i < mapLens;i++)
            {
                delta_x = realtime_x - global_map[i].center_x;
                delta_y = realtime_y - global_map[i].center_y;
                delta = sqrt(delta_x*delta_x + delta_y*delta_y);
                if(delta < near_distance)
                {
                    near_distance = delta;
                    id = i;
                }
            }
            std::cout<<"id"<<id<<std::endl;

            p_begin = id;
            //if(id<100){p_begin = 0;} else{p_begin = id - 100;}
            //if(id > mapLens-100){p_end = mapLens;} else{p_end = id+100;}

            if(id<20){p_begin = 0;} else{p_begin = id ;}
            if(id > mapLens-20){p_end = mapLens;} else{p_end = id+19;}
            sensor_msgs::PointCloud2 output;
            std::cout<<"p_begin"<<p_begin<<std::endl;
            std::cout<<"p_end"<<p_end<<std::endl;
            int j = 0;
            for(int i = p_begin;i<p_end;i++)
            {
                
                //  cloud.points[i].x= global_map[i].center_x;
                //  cloud.points[i].y= global_map[i].center_y;
                //  cloud.points[i].z= global_map[i].center_z;   
                cloud_ptr->points[j].x=global_map[i].center_x;
                cloud_ptr->points[j].y=global_map[i].center_y;
                cloud_ptr->points[j].z=global_map[i].center_z;
                std::cout<<"x"<<global_map[i].center_x<<",y: "<<global_map[i].center_y<<",z: "<<global_map[i].center_y<<std::endl;

                j++;
            }
            // pcl::toROSMsg(cloud,output);
            pcl::toROSMsg(*cloud_ptr,output);
            output.header.frame_id = "odom";
            ROS_INFO("I can can can can can can");
            map_pub.publish(output);

            // formWholeMapToMaker(marker_LR,marker_LL);
            // marker_LR_pub.publish(marker_LR);
            // marker_LL_pub.publish(marker_LL);
        }
        // formMapToMarker(m_lane,marker_cen,marker_lef,marker_rig,marker_body);
        // formMapPointsToMarker(cloud,marker_cen,marker_body);
        // formMapPointsToMarker(*cloud_ptr,marker_cen,marker_body);
        // marker_cen_pub.publish(marker_cen);
        loop_rate.sleep();
        ros::spinOnce();

    }
    return 0;
    
}